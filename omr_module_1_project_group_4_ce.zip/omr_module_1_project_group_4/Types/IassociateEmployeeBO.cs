﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface IassociateEmployeeBO
    {
        int Sroid
        {
            get;
            set;
        }
        int Associateid
        {
            get;
            set;
        }
        int Employeeid
        {
            get;
            set;
        }
    }
    }
