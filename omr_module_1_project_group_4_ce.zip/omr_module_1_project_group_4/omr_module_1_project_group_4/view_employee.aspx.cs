﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;

namespace omr_module_1_project_group_4
{
    public partial class view_employee : System.Web.UI.Page
    {
        public DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {          

            System.Web.UI.HtmlControls.HtmlAnchor a = (System.Web.UI.HtmlControls.HtmlAnchor)this.Page.Master.FindControl("view");
            a.Style.Add("background-color", "#4CAF50");
        }

        protected void getData_Click(object sender, EventArgs e)        
        {
            int id=0;
            try
            {
                id = int.Parse(getdata1.Text.ToString());
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Woowzaa! You wrote a novel there. Employee IDs are not that long!');window.location=\"/view_employee.aspx\";", true);

            }
            SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("usp_getEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@id", id));
                da.SelectCommand = cmd;
                da.Fill(dt);
                string dataString="";

                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            try
                            {
                                string eid = id.ToString();
                                string fn = row["FirstName"].ToString();
                                string ln = row["LastName"].ToString();
                                string dob = row["DateOfBirth"].ToString();

                                string gender = row["Gender"].ToString();
                                string email = row["Email"].ToString();
                                string add = row["Address"].ToString();
                                string cn = row["ContactNo"].ToString();
                                string yoe = row["YearsofExperience"].ToString();
                                string doj = row["DateOfJoining"].ToString();


                                string ctc = row["CTC"].ToString();
                                string role = row["Role"].ToString();
                                string place = row["Place"].ToString();
                                string password = row["Password"].ToString();
                                string status = row["Status"].ToString();




                                dataString = eid + "$%$" + fn + "$%$" + ln + "$%$" + dob + "$%$" + gender + "$%$" + email + "$%$" + add + "$%$" + cn + "$%$" + yoe + "$%$" + doj + "$%$" + ctc + "$%$" + role + "$%$" + place + "$%$" + password + "$%$" + status;
                            }
                            catch (Exception Ex)
                            {
                                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

                            }
                        }



                        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "f('" + dataString + "')", true);
                        userhead.Text = id.ToString();
                        //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>show();</script>", false);
                        //ScriptManager.RegisterStartupScript(this, GetType(), "InvokeButton", "show();", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alertandreload();", true);

                    }
                }
            }
            catch (Exception x)
            {
                //Response.Write("<script>alert('"+x+"');</script>");
            }
            finally
            {
                cmd.Dispose();
                con.Close();
               // dataviewgrid.DataBind();

            }

            card.Style.Add("height", "450px");
            card.Style.Add("width", "97%");
            card.Style.Add("transition", "all 1.5s ease");



        }

        protected void submitEditToServer_Click(object sender, EventArgs e)
        {

            EmployeeBO empobj = new EmployeeBO();
            try
            {
                empobj.Id = int.Parse(HiddenID.Value);
                empobj.FirstName = fnjs.Text.Replace(",", "");
                empobj.LastName = lnjs.Text.Replace(",", "");
                empobj.Gender = Request.Form["Gender"].ToString();
                empobj.Dob = DateTime.Parse(dobjs.Text.Replace(",", ""));
                empobj.Email = emailjs.Text.Replace(",", "");
                empobj.Address = addressjs.Text.Replace(",", "");
                empobj.Contactno = long.Parse(contactnojs.Text.Replace(",", ""));
                empobj.Yoe = int.Parse(yoejs.Text.Replace(",", ""));
                empobj.Doj = DateTime.Parse(dojjs.Text.Replace(",", ""));
                empobj.Ctc = float.Parse(ctcjs.Text.Replace(",", ""));

                empobj.Password = passwordjs.Text.Replace(",", "");


                empobj.Role = Request.Form["role"].ToString();

                empobj.Place = placejs.Text.Replace(",", "");

                empobj.Status = Request.Form["Status"].ToString();
            }
            catch(Exception Ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

            }
            EmployeeBLL bllobj = new EmployeeBLL();
            int isSuccess = bllobj.EditEmployee(empobj);

            if(isSuccess==1)
            {
               // ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('You've successfully saved the changes')", true);
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "f('success')", true);

            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('I dont like this message')", true);

            }


        }
    }

}