﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
using System.Data;
using System.Data.SqlClient;

namespace omr_module_1_project_group_4
{
    public partial class associate : System.Web.UI.Page
    {

        associateEmployeeBO objbo = new associateEmployeeBO();
        associateEmployeeBLL objbll = new associateEmployeeBLL();
        //bo objbo = new bo();
        //bll objbll = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btngetdata_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                
                objbo.employeeid = int.Parse(txtempid.Value);
                objbo.sroid = int.Parse(DropDownList1.SelectedItem.Value);
                objbo.Description = txtdescription.Value;
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Operation Terminated. Attempt to operate on invalid data. ');", true);

            }
            i = objbll.getdata(objbo);
            if(i > 1)
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Association ID : " + i + " : We have associated the given Employee and Office with the association ID as shown.');", true);
            else
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Invalid Command. Operation Terminated. Possible Conflicts : Employee already associated or Employee ID is invalid/ undesignated');", true);

        }



        protected void viewall_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            GridView2.DataSource = objbll.viewall();
            GridView2.DataBind();
        }

        protected void Btn_edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("editassociate.aspx");
        }
    }

}