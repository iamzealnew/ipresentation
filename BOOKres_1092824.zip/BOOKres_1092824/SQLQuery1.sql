create table tbl_bookres_1092824(resid int primary key identity(1,1),bookname varchar(20),descp varchar(100),authorname varchar(20),category varchar(20),userid varchar(10)) 
insert into tbl_bookres_1092824 values('DPSD','electronics','jk rowling','engineering','jkr')
insert into tbl_bookres_1092824 values('EVS','environmental based','kumar','science','kumar')
insert into tbl_bookres_1092824 values('MBA','buisness oriented','mathi','management','mathi')


select * from tbl_bookres_1092824

alter procedure tbl_resbook_1092824(@bookname varchar(20),@descp varchar(100),@authorname varchar(20),@category varchar(20),@userid varchar(20))
as
begin
insert into tbl_bookres_1092824(bookname,descp,authorname,category,userid)
values(@bookname,@descp,@authorname,@category,@userid)
end

create procedure tbl_viewbook_1092824(@userid varchar(10))
as
begin
select * from tbl_bookres_1092824
where userid=@userid
end
execute tbl_viewbook_1092824 'kumar'


create procedure tbl_delreservation_1092824(@userid varchar(20))
as
begin
delete from tbl_bookres_1092824
where userid=@userid
end
create procedure tbl_del_1092824(@resid int)
as
begin
delete from tbl_bookres_1092824
where resid=@resid
end
execute tbl_del_1092824 8

create procedure tbl_resbooks_1092824(@bookname varchar(20),@descp varchar(100),@authorname varchar(20),@category varchar(20))
as
begin
insert into tbl_bookres_1092824(bookname,descp,authorname)
values(@bookname,@descp,@authorname) 
(select * from tbl_bookres_1092824 where category=@category)
end
execute tbl_resbooks_1092824 'MBA','buisness oriented','mathi','management'
create procedure insertby_category(@category varchar(20))



