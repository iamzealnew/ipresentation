﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data;
using System.Data.SqlClient;

namespace DALL
{
    public class bookresdall
    {
        public int resbook(bookresbo bo)
        {
            string str = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN09_MMS55_TEST;User Id=mms55test;Password=mms55test";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "tbl_resbook_1092824";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@bookname", bo.Bookname);
            cmd.Parameters.AddWithValue("@descp", bo.Descp);
            cmd.Parameters.AddWithValue("@authorname", bo.Authorname);
            cmd.Parameters.AddWithValue("@category", bo.Category);
            cmd.Parameters.AddWithValue("@userid", bo.Userid);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            return r;
        }
        public DataSet viewbook(bookresbo bo)
        {
            string str = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN09_MMS55_TEST;User Id=mms55test;Password=mms55test";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "tbl_viewbook_1092824";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@userid", bo.Userid);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds; 
        }
        public DataSet delres(bookresbo bo)
        {
            string str = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN09_MMS55_TEST;User Id=mms55test;Password=mms55test";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "tbl_delreservation_1092824";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@userid", bo.Userid);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds;
        }
    }
}
