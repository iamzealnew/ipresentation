﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DALL;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class bookresbll
    {
        public int resbook( string bookname, string descp, string authorname,string category,string userid)
        {
            bookresbo bo = new bookresbo(bookname, descp, authorname, category, userid);
            bookresdall dall = new bookresdall();
            int r = dall.resbook(bo);
            return r;
        }
        public DataSet viewbook( string userid)
        {
            bookresbo bo = new bookresbo(userid);
            bookresdall dall = new bookresdall();
            DataSet ds = dall.viewbook(bo);
            return ds;
        }
        public DataSet delres(string userid)
        {
            bookresbo bo = new bookresbo(userid);
            bookresdall dall = new bookresdall();
            DataSet ds = dall.delres(bo);
            return ds;
        }
    }
}
