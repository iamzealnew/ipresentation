﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            string word = TextBox2.Text;
            if(FormsAuthentication.Authenticate(name,word))
            {
                FormsAuthentication.RedirectFromLoginPage(name, false);
                Session["userid"] = TextBox1.Text;
                Response.Redirect("homepage.aspx");
            }
           else
            {
                Label1.Text = "inavalid login";
            }
        }
    }
}