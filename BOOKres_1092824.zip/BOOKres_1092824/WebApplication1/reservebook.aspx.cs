﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;

namespace WebApplication1
{
    public partial class reservebook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string user = Session["userid"].ToString();
            Label1.Text = user;
            TextBox3.Text = Session["Category"].ToString();
            TextBox3.Enabled = false;          
            TextBox5.Text = user;
            TextBox5.Enabled = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            bookresbll bll = new bookresbll();
            string bookname = TextBox1.Text;
            string descp = TextBox2.Text;
            string author = TextBox4.Text;
            string category = TextBox3.Text;
            string userid = TextBox5.Text;


            int r = bll.resbook(bookname, descp, author,category,userid);
            if(r>0)
            {
                Label2.Text = "inserted successfuly";
            }
            else
            {
                Label2.Text = "not inserted";
            }
        }

    }
}