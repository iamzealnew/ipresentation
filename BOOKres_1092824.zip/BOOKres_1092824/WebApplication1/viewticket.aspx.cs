﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BLL;

namespace WebApplication1
{
    public partial class viewticket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string user = Session["userid"].ToString();
            Label8.Text = user;
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            bookresbll bll = new bookresbll();
            string userid = ((Label)GridView1.Rows[e.RowIndex].FindControl("Label6")).Text;
            bll.delres(userid);

            GridView1.EditIndex = -1;
            binddata();
        }
          

        protected void Button2_Click(object sender, EventArgs e)
        {
            binddata();
        }
        public void binddata()
        {
            bookresbll bll = new bookresbll();
            
            string userid = TextBox1.Text;
            GridView1.DataSource = bll.viewbook(userid);
            GridView1.DataBind();
        }
        
    }
}