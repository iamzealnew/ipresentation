﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class bookresbo
    {
        int resid;
        string bookname; 
        string descp ;
        string authorname ;
       string category ;
       string userid ;

        public int Resid
        {
            get
            {
                return resid;
            }

            set
            {
                resid = value;
            }
        }

        public string Bookname
        {
            get
            {
                return bookname;
            }

            set
            {
                bookname = value;
            }
        }

        public string Descp
        {
            get
            {
                return descp;
            }

            set
            {
                descp = value;
            }
        }

        public string Authorname
        {
            get
            {
                return authorname;
            }

            set
            {
                authorname = value;
            }
        }

        public string Category
        {
            get
            {
                return category;
            }

            set
            {
                category = value;
            }
        }

        public string Userid
        {
            get
            {
                return userid;
            }

            set
            {
                userid = value;
            }
        }
        public  bookresbo(int resid,string bookname,string descp,string authorname,string category,string userid )
        {
            this.resid = resid;
            this.bookname = bookname;
            this.descp = descp;
            this.authorname = authorname;
            this.category = category;
            this.userid = userid;
        }
        public bookresbo( string bookname, string descp, string authorname,string category,string userid)
        {
            
            this.bookname = bookname;
            this.descp = descp;
            this.authorname = authorname;
            this.category = category;
            this.userid = userid;


        }
        public bookresbo( string userid)
        {
           
            this.userid = userid;
        }
    }
}
