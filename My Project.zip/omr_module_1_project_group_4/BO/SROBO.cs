﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class SROBO
    {
        
        int sROID;
        string address_1;
        string address_2;
        string areaLocation;
        string district;
        string state;
        int pincode;
        string country;
        string bankName;
        long officeContact;
        string branch;
        string ifscCode;
        string createdby;
        DateTime createdDate;
        string modifiedby;
        long bankAccount;
        DateTime modifiedDate;
        Boolean status;
        public SROBO()
        { }
        public int SROID
        {
            get
            {
                return sROID;
            }

            set
            {
                sROID = value;
            }
        }

        public string Address_1
        {
            get
            {
                return address_1;
            }

            set
            { 
                address_1 = value;
            }
        }

        public string Address_2
        {
            get
            {
                return address_2;
            }

            set
            {
                address_2 = value;
            }
        }

        public string AreaLocation
        {
            get
            {
                return areaLocation;
            }

            set
            {
                areaLocation = value;
            }
        }

        public string District
        {
            get
            {
                return district;
            }

            set
            {
                district = value;
            }
        }

        public string State
        {
            get
            {
                return state;
            }

            set
            {
                state = value;
            }
        }

        public string Country
        {
            get
            {
                return country;
            }

            set
            {
                country = value;
            }
        }

        public string BankName
        {
            get
            {
                return bankName;
            }

            set
            {
                bankName = value;
            }
        }

        public string Branch
        {
            get
            {
                return branch;
            }

            set
            {
                branch = value;
            }
        }

        public string IFSCCode
        {
            get
            {
                return ifscCode;
            }

            set
            {
                ifscCode = value;
            }
        }

        public string Createdby
        {
            get
            {
                return createdby;
            }

            set
            {
                createdby = value;
            }
        }

        public string Modifiedby
        {
            get
            {
                return modifiedby;
            }

            set
            {
                modifiedby = value;
            }
        }

        public long BankAccount
        {
            get
            {
                return bankAccount;
            }

            set
            {
                bankAccount = value;
            }
        }

        public DateTime ModifiedDate
        { 
            get
            {
                return modifiedDate;
            }

            set
            {
                modifiedDate = value;
            }
        }

        public bool Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public int Pincode
        {
            get
            {
                return pincode;
            }

            set
            {
                pincode = value;
            }
        }

        public long OfficeContact
        {
            get
            {
                return officeContact;
            }

            set
            {
                officeContact = value;
            }
        }
    }
}