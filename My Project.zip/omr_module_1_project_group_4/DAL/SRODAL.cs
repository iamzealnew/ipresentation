﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class SRODAL
    {

        public int EditSRO(SROBO objbo)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            int ret = 0;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_editSRO", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@sroid",objbo.SROID));
            cmd.Parameters.Add(new SqlParameter("@addressline1",objbo.Address_1));
            cmd.Parameters.Add(new SqlParameter("@addressline2",objbo.Address_2));
            cmd.Parameters.Add(new SqlParameter("@area",objbo.AreaLocation));
            cmd.Parameters.Add(new SqlParameter("@district",objbo.District));
            cmd.Parameters.Add(new SqlParameter("@state",objbo.State));
            cmd.Parameters.Add(new SqlParameter("@pincode",objbo.Pincode));
            cmd.Parameters.Add(new SqlParameter("@officecontact",objbo.OfficeContact));
            cmd.Parameters.Add(new SqlParameter("@sroanno",objbo.BankAccount));
            cmd.Parameters.Add(new SqlParameter("@bankname",objbo.BankName));
            cmd.Parameters.Add(new SqlParameter("@branch",objbo.Branch));
            cmd.Parameters.Add(new SqlParameter("@ifsc",objbo.IFSCCode));

            ret = cmd.ExecuteNonQuery();
            
            return ret;
        }

    }
}
