﻿using BO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class designateEmployeeDAL
    {
        public int addSRAssistant(designateEmployeeBO objsra)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            int ret = 0;
            int returnsrid=0;
            conn.Open();

            SqlCommand cmd2 = new SqlCommand();
            cmd2 = new SqlCommand("usp_viewSRAemployeeid", conn);
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.Parameters.Add(new SqlParameter("@emailid", objsra.EmailId));

            SqlDataReader dr = cmd2.ExecuteReader();

            while (dr.Read())
            {
                returnsrid = Convert.ToInt32(dr[0].ToString());
            }
            dr.Close();

            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_addsrassistant", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmployeesrID", returnsrid);
            cmd.Parameters.AddWithValue("@Name", objsra.Name);
            cmd.Parameters.AddWithValue("@Designation", objsra.Designation);
            cmd.Parameters.AddWithValue("@EmailId", objsra.EmailId);
            cmd.Parameters.AddWithValue("@Address", objsra.Address);
            cmd.Parameters.AddWithValue("@ContactNo", objsra.ContactNo);
            cmd.Parameters.AddWithValue("@Createdby", objsra.CreatedBy);
            cmd.Parameters.AddWithValue("@CreatedDate", objsra.CreatedDate);
            cmd.Parameters.AddWithValue("@Modifiedby", objsra.ModifiedBy);
            cmd.Parameters.AddWithValue("@ModifiedDate", objsra.ModifiedDate);
            cmd.Parameters.AddWithValue("@Status", objsra.Status);
            ret = cmd.ExecuteNonQuery();

            conn.Close();

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            if (ret == 1)
            {
                return returnsrid;

            }
            else
                return 0;

        }


    }
}

