﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;

namespace omr_module_1_project_group_4
{
    public partial class SROffice : System.Web.UI.Page
    {
        public DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter da = new SqlDataAdapter();
                dt = new DataTable();
                try
                {
                    cmd = new SqlCommand("usp_getsro", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand = cmd;
                    da.Fill(dt);
                    //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>show();</script>", false);
                    //ScriptManager.RegisterStartupScript(this, GetType(), "InvokeButton", "show();", false);
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    cmd.Dispose();
                    con.Close();

                }
            }


        }

        protected void submitToServer_Click(object sender, EventArgs e)
        {
            SROBO objbo = new SROBO();

            String s =  HiddenID.Value;

            objbo.SROID = int.Parse(s);
            objbo.Address_1 = addL1.Text.ToString();
            objbo.Address_2 = addL2.Text.ToString();
            objbo.AreaLocation = Area.Text.ToString();
            objbo.District = District.Text.ToString();
            objbo.Pincode = int.Parse(PinCode.Text.ToString());
            objbo.State = State.Text.ToString();
            objbo.OfficeContact = long.Parse(OfficeContact.Text.ToString());
            objbo.BankAccount = long.Parse(sroBA.Text.ToString());
            objbo.BankName = BankName.Text.ToString();
            objbo.Branch = Branch.Text.ToString();
            objbo.IFSCCode = IFSC.Text.ToString();

            SROBLL bllobj = new SROBLL();
            int isSuccessful = bllobj.EditSRO(objbo);

            if(isSuccessful == 1)
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Data Successfully updated!')", true);

            }




        }
               

        protected void filterbtn_Click(object sender, EventArgs e)
        {

            string filterSROID = filSroID.Text;
            String filterDistrict = filDistrict.Text;
            String filterArea = filArea.Text;
            String filterState = filState.Text;
            String filterBankName = filBankName.Text;
            String concatinator="I will generate the querry";
            
            if (hasMeetAll.Checked)
                concatinator = "AND ";
            else
                concatinator = "OR  ";
            String whereSROID = " SROID = '" + filterSROID + "' ";
            String whereDistrict = " District = '" + filterDistrict + "' ";
            String whereArea = "Area = '" + filterArea + "' ";
            String whereState = "State = '" + filterState + "' ";
            String whereBankName = "Bankname = '" + filterBankName + "'";

            String querry = "select * from addsrooffice where";

           

                if(filterSROID != "")
                {
                    querry = querry + whereSROID + concatinator;
                }

                if (filterDistrict != "")
                {
                     querry = querry + whereDistrict + concatinator;
                }

                if (filterState != "")
                {
                    querry = querry + whereState + concatinator;
                }
                if (filterBankName != "")
                {
                   querry = querry + whereBankName + concatinator;
                }
                if (filterArea != "")
                {
                   querry = querry + whereArea + concatinator;
                }

                querry = querry.Substring(0, querry.Length - 4);
          
            

            SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            dt = new DataTable();
            try
            {
                cmd = new SqlCommand(querry, con);
                da.SelectCommand = cmd;
                da.Fill(dt);
                //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "script", "<script type='text/javascript'>show();</script>", false);
                //ScriptManager.RegisterStartupScript(this, GetType(), "InvokeButton", "show();", false);
            }
            catch (Exception x)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();

            }




        }
    }
}