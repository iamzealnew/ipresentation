﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
namespace DAL
{
    public class SRODAL
    {

        public int EditSRO(SROBO objbo)
        {

            return 0;
        }

    }
}
